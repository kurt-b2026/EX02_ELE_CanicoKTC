/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex02_ele_canicoktc;

/**
 *
 * @author Kurt Travis Canico
 */
public class Song {
    String title;
    String artist;
    int length;
    
    public Song(String t, String a, int l){
        title = t;
        artist = a;
        length = l;
    }
}
