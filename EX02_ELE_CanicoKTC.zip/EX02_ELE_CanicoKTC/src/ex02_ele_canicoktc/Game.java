/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex02_ele_canicoktc;

/**
 *
 * @author Kurt Travis Canico
 */
public class Game {
    String name;
    double gameYear;
    int sizeMB;
    
    public Game(String n, double g, int s){
        name = n;
        gameYear = g;
        sizeMB = s;
    }
}
