/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex02_ele_canicoktc;

/**
 *
 * @author Kurt Travis Canico
 */
public class Singer {
    String name;
    String favoriteSong;
    int noOfPerformances;
    double earnings;
    
    public Singer(Song s, String n, double e, int p){
        favoriteSong = s.title; 
        name = n;
        earnings = e;
        noOfPerformances = p;
    }
    
    public void performForAudience(int noOfPeople){
        noOfPerformances++; 
        earnings = noOfPeople * earnings;
    }
    
    public void changeFavSong(Song x){
        favoriteSong = x.title;
    }
}
